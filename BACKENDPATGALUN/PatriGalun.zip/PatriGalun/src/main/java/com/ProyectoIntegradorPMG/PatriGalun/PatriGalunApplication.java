package com.ProyectoIntegradorPMG.PatriGalun;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatriGalunApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatriGalunApplication.class, args);
	}

}
