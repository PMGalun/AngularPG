package com.ProyectoIntegradorPMG.PatriGalun;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatriGalunApplicationTests {

	@Test
	void contextLoads() {
	}

}
